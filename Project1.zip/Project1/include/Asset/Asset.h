﻿#pragma once
#include "../Share/Object/Object.h"

class CAsset abstract : public CObject
{
public:
	CAsset();
	virtual ~CAsset();
};

