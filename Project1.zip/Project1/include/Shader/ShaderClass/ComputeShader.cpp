﻿#include "ComputeShader.h"

CComputeShader::CComputeShader()
{

}
CComputeShader::~CComputeShader()
{

}
bool CComputeShader::Init()
{
	return true;
}
void CComputeShader::SetShader()
{

}